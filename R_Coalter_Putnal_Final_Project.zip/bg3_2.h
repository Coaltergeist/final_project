
//{{BLOCK(bg3_2)

//======================================================================
//
//	bg3_2, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 89 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 2848 + 2048 = 5408
//
//	Time-stamp: 2017-12-04, 01:12:31
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BG3_2_H
#define GRIT_BG3_2_H

#define bg3_2TilesLen 2848
extern const unsigned short bg3_2Tiles[1424];

#define bg3_2MapLen 2048
extern const unsigned short bg3_2Map[1024];

#define bg3_2PalLen 512
extern const unsigned short bg3_2Pal[256];

#endif // GRIT_BG3_2_H

//}}BLOCK(bg3_2)
